# -*- coding:utf-8 -*-
from pushbullet import Pushbullet

API_KEY ='o.6mJ7H4xGm2z6j1KcqpD70ft0Gf6e0yMl'
pb = Pushbullet(API_KEY)
device = pb.devices[0]

def push_sms():

    mobile = '1414'
    sms = 'xin Chào!'
    # print ('************ hello!!!!! **************')
    return pb.push_sms(device, mobile, sms)

push_sms()