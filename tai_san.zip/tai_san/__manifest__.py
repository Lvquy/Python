# -*- coding: utf-8 -*-

{
    "name": "Quản lý tài sản",
    "summary": "custom...",
    "version": "",
    "category": "custom lds",
    "website": "https://ldsvn.com/",
    "author": "Lv Quy, IT LDS",
    "license": "LGPL-3",
    "depends": ['hr'
                ],
    "data": [
        'views/filter.xml',
        'views/view.xml',
        'data/data.xml'
    ],
    'qweb': [],
    'application'   : True,
    'auto_install'  : False,
}
