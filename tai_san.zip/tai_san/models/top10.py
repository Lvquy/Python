# -*- coding: utf-8 -*-
from odoo import fields, models, api


class Top10(models.Model):
    # _name = 'top10'
    _inherit = 'hr.employee'

    def get_top10(self):
        a= self.env['hr.employee'].search([],order='tong_gt_ts desc', limit=5)
        for i in a:
            print i.name, i.tong_gt_ts
