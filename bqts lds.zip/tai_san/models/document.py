# -*- coding: utf-8 -*-

from odoo import api, fields, models,_



class Document(models.Model):
    _name='doc.lds'

    document= fields.Html(string='Hướng dẫn sử dụng nội bộ')