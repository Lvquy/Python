# -*- coding: utf-8 -*-
from odoo import fields, models


class HR(models.Model):
    _inherit = 'hr.employee'

    email_noibo = fields.Char(string="Email nội bộ")
    work_email = fields.Char(string="Email ngoại bộ")
    so_the = fields.Char(string="Số thẻ", help='Số thẻ nhân viên', required=True)
    _sql_constraints = [
        ('so_the_uniq', 'UNIQUE(so_the)', 'Số thẻ này đã tồn tại, Kiểm tra lại!')
    ]
    thiet_bi = fields.One2many('tai.san','nguoi_bao_quan',string='Thiet bi', readonly=True)
    server = fields.Char(string="Server lưu trữ")

class Lichsu(models.Model):
    _name='lich.su'

    ref_hr = fields.Many2one('tai.san')
    thiet_bi = fields.Char(string="Thiết bị")
    nguoi_bq = fields.Char(string="Người bảo quản")
    note = fields.Text(string='Note')
    tu_ngay = fields.Date(string='Từ ngày')
    his_type = fields.Selection([('bq','Bắt đầu bảo quản'),('kho','Trả kho'),('phe','Đã báo phế'),('sc','Sửa chữa')],string='Thuộc Kiểu')