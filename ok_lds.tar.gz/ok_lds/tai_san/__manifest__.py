# -*- coding: utf-8 -*-

{
    "name": "Quản lý tài sản",
    "summary": "custom...",
    "version": "",
    "category": "custom lds",
    "website": "https://ldsvn.com/",
    "author": "Lv Quy, IT LDS",
    "license": "LGPL-3",
    "depends": ['hr','report','contacts'
                ],
    "data": [
        'data/data.xml',
        'data/ir.cron.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/filter.xml',
        'views/view.xml',
        'views/lich_su.xml',
        'views/kanban.xml',
        'report/menu_report.xml',
        'report/bao_quan_ts.xml',
        'report/thong_tin_ts.xml',
    ],
    'qweb': [],
    'application'   : True,
    'auto_install'  : False,
}