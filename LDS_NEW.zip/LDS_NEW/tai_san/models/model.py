# -*- coding: utf-8 -*-
from odoo import api, fields, models,_
from odoo.exceptions import UserError
import datetime, time
from datetime import date
import dateutil.parser
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT


class HR(models.Model):
    _inherit = 'hr.employee'

    email_noibo = fields.Char(string="Email nội bộ")
    work_email = fields.Char(string="Email ngoại bộ")
    so_the = fields.Char(string="Số thẻ", help='Số thẻ nhân viên', required=True)
    thiet_bi = fields.One2many('tai.san','nguoi_bao_quan',string='Thiet bi', readonly=True)
    server = fields.Char(string="Server lưu trữ")

class Lichsu(models.Model):
    _name='lich.su'

    ref_hr = fields.Many2one('tai.san')
    thiet_bi = fields.Char(string="Thiết bị")
    nguoi_bq = fields.Many2one('hr.employee', string="Người bảo quản")
    note = fields.Text(string='Note')
    tu_ngay = fields.Date(string='Từ ngày')
    his_type = fields.Selection([('bq','Bắt đầu bảo quản'),('kho','Trả kho'),('phe','Đã báo phế'),('sc','Sửa chữa')],string='Thuộc Kiểu')