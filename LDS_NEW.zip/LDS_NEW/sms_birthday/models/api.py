# -*- coding:utf-8 -*-
from odoo import models, fields, api
import pushbullet
import dateutil.parser

class APIKEY(models.Model):
    _name = 'api.key'

    api_key = fields.Char(string='API KEY', required=True)
    name = fields.Char(string='Name')
    mobile = fields.Char(string="Mobile", required=True)
    email = fields.Char(string="Email", required=True)
    create_date =fields.Datetime(string="Create Date")
    hide = fields.Boolean(string="Hide token", default=False)
    status = fields.Selection([('off','OFF'),('on','ON')],default='off',string='Trạng thái API')
    count = fields.Integer(string='Số lần gửi thành công', default=0, readonly=True)

    def test(self):
        pb = pushbullet.Pushbullet(self.api_key)
        device = pb.devices[0]
        self.count +=1
        # pb.push_sms(device,self.mobile,'API SMS: Thành công rồi, haha')

    def change_status(self):
        if self.status == 'off':
            stt_on = self.env['api.key'].search([('status','=','on')],limit=1)
            if stt_on.status:
                print stt_on.status
                stt_on.status = 'off'
            self.status = 'on'
        else:
            self.status = 'off'
