# -*- coding:utf-8 -*-
from odoo import models, fields, api
import datetime
from datetime import date
import pushbullet
import dateutil.parser
from odoo.exceptions import UserError

class Birthday(models.Model):
    _inherit = 'hr.employee'

    sms_birthday = fields.Boolean(string='Tự động gửi SMS chúc mừng sinh nhật.', default=False)

    @api.onchange('sms_birthday')
    def check_sms(self):
        if self.sms_birthday is True:
            if not self.birthday or not self.mobile_phone:
                raise UserError('Chú ý! Cần có thông tin ngày sinh và SĐT')

    def auto_sms(self):
        if self.env['api.key'].search([], limit=1).status == 'on':
            API_KEY = self.env['api.key'].search([], limit=1).api_key
            # print API_KEY
            pb = pushbullet.Pushbullet(API_KEY)
            device = pb.devices[0]
            # pb.push_sms(device, '1414', 'tttb')

            data = self.env['hr.employee']
            id_all = data.search([('sms_birthday','=',True)])
            # id_need = data.browse(id_all)
            # # print id_need
            for i in id_all:
                day = date.today().day
                month = date.today().month
                birthday = i.birthday
                birthday_day = dateutil.parser.parse(birthday).day
                birthday_month = dateutil.parser.parse(birthday).month
                if birthday_month == month and birthday_day == day:
                    id_need = data.browse(i.id)
                    print id_need.name
                    mobile= id_need.mobile_phone
                    sms = "Chúc bạn " + str(id_need.name) + " Sinh nhật vui vẻ! " + str(birthday)
                    a =self.env['api.key'].search([('status','=','on')], limit=1)
                    a.count += 1
                    pb.push_sms(device, mobile, sms)