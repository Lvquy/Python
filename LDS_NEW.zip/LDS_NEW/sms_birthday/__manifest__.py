# -*- coding: utf-8 -*-
{
    "name": "Auto SMS Birthday",
    "summary":"",
    "author":"Lv Quy",
    "license":'LGPL-3',
    "description":'''Push sms''',
    "depends":['base','hr'],
    "data":[
        # 'view.xml'
        'data/data.xml'
    ],
    'installable': True,
    'application'   : True,
    'auto_install'  : False,
}